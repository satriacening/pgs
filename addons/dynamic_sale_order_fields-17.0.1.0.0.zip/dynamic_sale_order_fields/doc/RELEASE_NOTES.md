## Module <dynamic_sale_order_fields>

#### 14.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for Sale Order Custom Fields
