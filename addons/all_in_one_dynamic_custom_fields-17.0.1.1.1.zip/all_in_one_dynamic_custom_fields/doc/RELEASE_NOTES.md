## Module <all_in_one_dynamic_custom_fields>

#### 08.01.2024
#### Version 17.0.1.0.0
##### ADD

- Initial commit for All in One Custom Dynamic Fields

#### 13.06.2024
#### Version 17.0.1.1.1
##### UPDATE
- The latest module update includes enhancements to the list view configuration. You can now add the newly created field to the selected list view at the desired position, with the option to enable or disable its visibility by default.
