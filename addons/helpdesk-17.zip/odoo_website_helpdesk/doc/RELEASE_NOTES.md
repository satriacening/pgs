## Module <odoo_website_helpdesk>

#### 18.07.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Website Helpdesk Support Ticket Management.

#### 17.10.2024
#### Version 17.0.1.0.1
##### ADD
- Updated access for the tickets in portal.

#### 12.02.2025
#### Version 17.0.1.0.2
##### UPDT
-A new contact record is created upon form submission.

