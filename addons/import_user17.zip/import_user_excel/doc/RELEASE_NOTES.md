## Module <import_user_excel>

#### 20.04.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Import User with Access rights
